package com.portfolio.portfoliogg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioggApplicationTests {

	@Test
	void contextLoads() {
	}

}
