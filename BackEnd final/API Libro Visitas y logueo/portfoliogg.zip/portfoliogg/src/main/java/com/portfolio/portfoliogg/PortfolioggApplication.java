package com.portfolio.portfoliogg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioggApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioggApplication.class, args);
	}

}
